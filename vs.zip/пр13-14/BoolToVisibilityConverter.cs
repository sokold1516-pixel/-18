﻿
using System;
using System.Globalization;
using System.Windows.Data;

namespace пр13_14
{
    public class BoolToBlockTextConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool isBlocked && isBlocked)
                return "🔓 Разблокировать";
            return "🔒 Заблокировать";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}