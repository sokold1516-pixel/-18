﻿using System.Collections.ObjectModel;
using System.Windows;

namespace пр13_14.Pages
{
    public partial class RoleSelectionDialog : Window
    {
        public string SelectedRole { get; private set; }

        public RoleSelectionDialog(string currentRole)
        {
            InitializeComponent();

            var roles = new ObservableCollection<RoleItem>
            {
                new RoleItem { RoleName = "Admin" },
                new RoleItem { RoleName = "Manager" },
                new RoleItem { RoleName = "User" }
            };

            LbRoles.ItemsSource = roles;

            foreach (RoleItem item in LbRoles.Items)
            {
                if (item.RoleName == currentRole)
                {
                    LbRoles.SelectedItem = item;
                    break;
                }
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (LbRoles.SelectedItem is RoleItem selected)
            {
                SelectedRole = selected.RoleName;
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите роль", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }

    public class RoleItem
    {
        public string RoleName { get; set; }
    }
}