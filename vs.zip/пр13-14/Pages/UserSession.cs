﻿public static class UserSession
{
    public static int UserId { get; set; }
    public static string Login { get; set; }
    public static string FullName { get; set; }
    public static string Email { get; set; }
    public static string Role { get; set; }
    public static int RoleId { get; set; } 
    public static bool IsLoggedIn { get; set; }

    public static void Clear()
    {
        UserId = 0;
        Login = null;
        FullName = null;
        Email = null;
        Role = null;
        RoleId = 0;  
        IsLoggedIn = false;
    }

    public static bool IsAdmin => RoleId == 1;
    public static bool IsManager => RoleId == 2 || RoleId == 1;
    public static bool IsUser => RoleId == 3 || RoleId == 2 || RoleId == 1;
}