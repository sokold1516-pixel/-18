﻿using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace пр13_14.Pages
{
    public partial class AdminPanelPage : Page
    {
        private const string ConnectionString =
            @"Server=WIN-FQ3SEPJHQEH; Database=пр13; Integrated Security=true; TrustServerCertificate=True;";

        private DataTable _usersTable;

        public class RoleStat
        {
            public string RoleName { get; set; }
            public int Count { get; set; }
            public int TotalUsers { get; set; }
        }

        public class TopExhibit
        {
            public string Title { get; set; }
            public DateTime DateAdded { get; set; }
        }

        public AdminPanelPage()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (!UserSession.IsAdmin)
            {
                MessageBox.Show("Доступ запрещен. Требуются права администратора.",
                    "Ошибка доступа", MessageBoxButton.OK, MessageBoxImage.Warning);
                if (Application.Current.MainWindow is MainWindow mw)
                {
                    mw.MainFrame.Navigate(new CatalogPage());
                }
                return;
            }

            UserNameText.Text = UserSession.FullName;

            LoadUsers();
            LoadStatistics();
        }

        private void LoadUsers(string searchText = "")
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    conn.Open();
                    string query = @"SELECT u.UserID, u.Login, u.FullName, u.Email, u.IsBlocked, 
                                            r.RoleID, r.RoleName
                                     FROM Users u
                                     LEFT JOIN Roles r ON u.RoleID = r.RoleID
                                     WHERE 1=1";

                    if (!string.IsNullOrWhiteSpace(searchText))
                    {
                        query += " AND (u.FullName LIKE @Search OR u.Login LIKE @Search OR u.Email LIKE @Search)";
                    }

                    query += " ORDER BY u.UserID";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        if (!string.IsNullOrWhiteSpace(searchText))
                        {
                            cmd.Parameters.AddWithValue("@Search", "%" + searchText + "%");
                        }

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            _usersTable = new DataTable();
                            adapter.Fill(_usersTable);
                            DgUsers.ItemsSource = _usersTable.DefaultView;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки пользователей: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadStatistics()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    conn.Open();

                    using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Exhibitss", conn))
                    {
                        TblTotalExhibits.Text = cmd.ExecuteScalar().ToString();
                    }

                    using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Users", conn))
                    {
                        TblTotalUsers.Text = cmd.ExecuteScalar().ToString();
                    }

                    using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM HallsStorages", conn))
                    {
                        TblTotalHalls.Text = cmd.ExecuteScalar().ToString();
                    }

                    string roleQuery = @"SELECT r.RoleName, COUNT(u.UserID) as UserCount
                                         FROM Roles r
                                         LEFT JOIN Users u ON r.RoleID = u.RoleID
                                         GROUP BY r.RoleID, r.RoleName
                                         ORDER BY r.RoleID";

                    var roleStats = new ObservableCollection<RoleStat>();
                    int totalUsers = Convert.ToInt32(TblTotalUsers.Text);

                    using (SqlCommand cmd = new SqlCommand(roleQuery, conn))
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            roleStats.Add(new RoleStat
                            {
                                RoleName = reader["RoleName"].ToString(),
                                Count = Convert.ToInt32(reader["UserCount"]),
                                TotalUsers = totalUsers
                            });
                        }
                    }
                    ListRoleStats.ItemsSource = roleStats;

                    string topQuery = @"SELECT TOP 5 Title, DateAdded 
                                        FROM Exhibitss 
                                        ORDER BY DateAdded DESC";
                    var topExhibits = new ObservableCollection<TopExhibit>();
                    using (SqlCommand cmd = new SqlCommand(topQuery, conn))
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            topExhibits.Add(new TopExhibit
                            {
                                Title = reader["Title"].ToString(),
                                DateAdded = Convert.ToDateTime(reader["DateAdded"])
                            });
                        }
                    }
                    LvTopExhibits.ItemsSource = topExhibits;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки статистики: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private int GetRoleIdByName(string roleName)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    conn.Open();
                    string query = "SELECT RoleID FROM Roles WHERE RoleName = @RoleName";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@RoleName", roleName);
                        var result = cmd.ExecuteScalar();
                        if (result != null)
                            return Convert.ToInt32(result);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка получения ID роли: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return -1;
        }

        private void UpdateUserRole(int userId, int newRoleId)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    conn.Open();
                    string query = "UPDATE Users SET RoleID = @RoleID WHERE UserID = @UserID";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@RoleID", newRoleId);
                        cmd.Parameters.AddWithValue("@UserID", userId);
                        cmd.ExecuteNonQuery();
                    }
                }
                LoadUsers(TxtUserSearch.Text);
                MessageBox.Show("Роль пользователя обновлена", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления роли: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateUserBlockStatus(int userId, bool isBlocked)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    conn.Open();
                    string query = "UPDATE Users SET IsBlocked = @IsBlocked WHERE UserID = @UserID";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@IsBlocked", isBlocked);
                        cmd.Parameters.AddWithValue("@UserID", userId);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка изменения статуса: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TxtUserSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadUsers(TxtUserSearch.Text);
        }

        private void BtnSearchUsers_Click(object sender, RoutedEventArgs e)
        {
            LoadUsers(TxtUserSearch.Text);
        }

        private void BtnEditRole_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var user = button?.Tag as DataRowView;
            if (user != null)
            {
                int userId = Convert.ToInt32(user["UserID"]);
                string currentRole = user["RoleName"].ToString();

                var roleDialog = new RoleSelectionDialog(currentRole);
                if (roleDialog.ShowDialog() == true)
                {
                    int newRoleId = GetRoleIdByName(roleDialog.SelectedRole);
                    if (newRoleId > 0)
                    {
                        UpdateUserRole(userId, newRoleId);
                    }
                    else
                    {
                        MessageBox.Show("Неверное название роли", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
            }
        }

        private void BtnToggleBlock_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var user = button?.Tag as DataRowView;
            if (user != null)
            {
                int userId = Convert.ToInt32(user["UserID"]);
                bool isBlocked = Convert.ToBoolean(user["IsBlocked"]);
                bool newBlockStatus = !isBlocked;

                UpdateUserBlockStatus(userId, newBlockStatus);
                LoadUsers(TxtUserSearch.Text);

                MessageBox.Show(newBlockStatus ? "Пользователь заблокирован" : "Пользователь разблокирован",
                    "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnRefreshStats_Click(object sender, RoutedEventArgs e)
        {
            LoadStatistics();
        }

        private void BtnBackToCatalog_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.MainWindow is MainWindow mw)
            {
                mw.MainFrame.Navigate(new CatalogPage());
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы уверены, что хотите выйти?", "Выход",
                MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                UserSession.Clear();
                if (Application.Current.MainWindow is MainWindow mw)
                {
                    mw.MainFrame.Navigate(new LoginPage());
                }
            }
        }
    }
}