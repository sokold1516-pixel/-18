﻿
using System;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using пр13_14.Pages;

namespace пр13_14.Pages
{
    public partial class LoginPage : Page
    {
        private const string ConnectionString =
            @"Server=WIN-FQ3SEPJHQEH; Database=пр13; Integrated Security=true; TrustServerCertificate=True;";

        public LoginPage()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginTextBox?.Text.Trim();
            string password = PasswordBox?.Password;

            if (string.IsNullOrWhiteSpace(login))
            {
                MessageBox.Show("Введите логин", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Введите пароль", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (var conn = new SqlConnection(ConnectionString))
                {
                    conn.Open();
                    string query = @"SELECT u.UserID, u.FullName, u.Email, u.IsBlocked, r.RoleID, r.RoleName
                 FROM Users u 
                 LEFT JOIN Roles r ON u.RoleID = r.RoleID
                 WHERE u.Login = @Login AND u.PasswordHash = @Password";

                    using (var cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Login", login);
                        cmd.Parameters.AddWithValue("@Password", password);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                bool isBlocked = reader["IsBlocked"] != DBNull.Value && Convert.ToBoolean(reader["IsBlocked"]);
                                if (isBlocked)
                                {
                                    MessageBox.Show("Аккаунт заблокирован. Обратитесь к администратору.",
                                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                    return;
                                }

                                UserSession.UserId = Convert.ToInt32(reader["UserID"]);
                                UserSession.Login = login;
                                UserSession.FullName = reader["FullName"] != DBNull.Value
                                    ? reader.GetString(reader.GetOrdinal("FullName"))
                                    : "Пользователь";
                                UserSession.Email = reader["Email"] != DBNull.Value
                                    ? reader.GetString(reader.GetOrdinal("Email"))
                                    : "";

                                UserSession.RoleId = reader["RoleID"] != DBNull.Value
                                    ? Convert.ToInt32(reader["RoleID"])
                                    : 3;  

                                UserSession.Role = reader["RoleName"] != DBNull.Value
                                    ? reader.GetString(reader.GetOrdinal("RoleName"))
                                    : "User";  

                                UserSession.IsLoggedIn = true;

                                MessageBox.Show($"Добро пожаловать, {UserSession.FullName}!\nРоль: {UserSession.Role}",
                                    "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                                if (Application.Current.MainWindow is MainWindow mw)
                                {
                                    
                                    if (UserSession.IsAdmin)
                                        mw.MainFrame.Navigate(new AdminPanelPage());
                                    else if (UserSession.IsManager)
                                        mw.MainFrame.Navigate(new CatalogPage());
                                    else
                                        mw.MainFrame.Navigate(new CatalogPage());
                                }
                                return;
                            }
                        }
                    }
                }
                MessageBox.Show("Неверный логин или пароль", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RegisterLink_Click(object sender, MouseButtonEventArgs e)
        {
            if (Application.Current.MainWindow is MainWindow mw)
            {
                mw.MainFrame.Navigate(new RegistrationPage());
            }
        }
    }
}