﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace пр13_14
{
    public static class DatabaseHelper
    {
        private static string connectionString =
            @"Server=WIN-FQ3SEPJHQEH; Database=пр13; Integrated Security=true; TrustServerCertificate=True;";

        public static bool TestConnection()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения:\n\n{ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        public static DataTable GetAllExhibits()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"SELECT e.ExhibitsID, e.InventoryNumber, e.Title, e.Description, 
                                            e.Material, e.EstimatedValue, e.Condition, e.DateAdded, e.ImageData,
                                            h.Name as HallName, exp.Title as ExpositionTitle,
                                            e.HallsStoragesID, e.ExpositionsID
                                    FROM Exhibitss e
                                    LEFT JOIN HallsStorages h ON e.HallsStoragesID = h.HallsStoragesID
                                    LEFT JOIN Expositions exp ON e.ExpositionsID = exp.ExpositionsID
                                    ORDER BY e.DateAdded DESC";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        return dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка получения экспонатов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
        }

        public static DataTable SearchExhibits(string searchText, int? hallId, int? expositionId, string sortBy, bool isAscending)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"SELECT e.ExhibitsID, e.InventoryNumber, e.Title, e.Description, 
                                            e.Material, e.EstimatedValue, e.Condition, e.DateAdded, e.ImageData,
                                            h.Name as HallName, exp.Title as ExpositionTitle,
                                            e.HallsStoragesID, e.ExpositionsID
                                    FROM Exhibitss e
                                    LEFT JOIN HallsStorages h ON e.HallsStoragesID = h.HallsStoragesID
                                    LEFT JOIN Expositions exp ON e.ExpositionsID = exp.ExpositionsID
                                    WHERE 1=1";

                    if (!string.IsNullOrWhiteSpace(searchText))
                    {
                        query += " AND (e.Title LIKE @Search OR e.Description LIKE @Search OR e.InventoryNumber LIKE @Search)";
                    }

                    if (hallId.HasValue && hallId.Value > 0)
                    {
                        query += " AND e.HallsStoragesID = @HallId";
                    }

                    if (expositionId.HasValue && expositionId.Value > 0)
                    {
                        query += " AND e.ExpositionsID = @ExpId";
                    }

                    string allowedSortFields = "Title, DateAdded, EstimatedValue, Condition, InventoryNumber";
                    if (!allowedSortFields.Contains(sortBy)) sortBy = "DateAdded";

                    query += $" ORDER BY e.{sortBy} {(isAscending ? "ASC" : "DESC")}";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        if (!string.IsNullOrWhiteSpace(searchText))
                            cmd.Parameters.AddWithValue("@Search", "%" + searchText + "%");

                        if (hallId.HasValue && hallId.Value > 0)
                            cmd.Parameters.AddWithValue("@HallId", hallId.Value);

                        if (expositionId.HasValue && expositionId.Value > 0)
                            cmd.Parameters.AddWithValue("@ExpId", expositionId.Value);

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            return dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка поиска: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
        }

        public static bool AddExhibit(string inventoryNumber, string title, string description,
            string material, decimal? estimatedValue, string condition,
            int? hallId, int? expositionId, byte[] imageData)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"INSERT INTO Exhibitss (InventoryNumber, Title, Description, 
                                    Material, EstimatedValue, Condition, DateAdded, 
                                    HallsStoragesID, ExpositionsID, ImageData) 
                                    VALUES (@InvNum, @Title, @Desc, @Mat, @EstVal, @Cond, GETDATE(), 
                                    @HallId, @ExpId, @Img)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@InvNum", inventoryNumber);
                        cmd.Parameters.AddWithValue("@Title", title);
                        cmd.Parameters.AddWithValue("@Desc", (object)description ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@Mat", (object)material ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@EstVal", (object)estimatedValue ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@Cond", (object)condition ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@HallId", (object)hallId ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@ExpId", (object)expositionId ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@Img", (object)imageData ?? DBNull.Value);

                        int result = cmd.ExecuteNonQuery();
                        return result > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка добавления: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        public static bool UpdateExhibit(int id, string inventoryNumber, string title, string description,
            string material, decimal? estimatedValue, string condition,
            int? hallId, int? expositionId, byte[] imageData, bool isImageChanged)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string imgPart = isImageChanged ? ", ImageData = @Img" : "";

                    string query = $@"UPDATE Exhibitss SET 
                                    InventoryNumber = @InvNum, 
                                    Title = @Title, 
                                    Description = @Desc, 
                                    Material = @Mat, 
                                    EstimatedValue = @EstVal, 
                                    Condition = @Cond, 
                                    HallsStoragesID = @HallId, 
                                    ExpositionsID = @ExpId
                                    {imgPart}
                                    WHERE ExhibitsID = @Id";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Id", id);
                        cmd.Parameters.AddWithValue("@InvNum", inventoryNumber);
                        cmd.Parameters.AddWithValue("@Title", title);
                        cmd.Parameters.AddWithValue("@Desc", (object)description ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@Mat", (object)material ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@EstVal", (object)estimatedValue ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@Cond", (object)condition ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@HallId", (object)hallId ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@ExpId", (object)expositionId ?? DBNull.Value);

                        if (isImageChanged)
                            cmd.Parameters.AddWithValue("@Img", (object)imageData ?? DBNull.Value);

                        int result = cmd.ExecuteNonQuery();
                        return result > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        public static bool DeleteExhibit(int id)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "DELETE FROM Exhibitss WHERE ExhibitsID = @Id";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Id", id);
                        int result = cmd.ExecuteNonQuery();
                        return result > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        public static DataTable GetAllHalls()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT HallsStoragesID, Name FROM HallsStorages", conn))
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        if (dt.Columns.Contains("HallsStoragesID") && dt.Columns.Contains("Name"))
                        {
                            DataRow row = dt.NewRow();
                            row["HallsStoragesID"] = 0;
                            row["Name"] = "-- Все залы --";
                            dt.Rows.InsertAt(row, 0);
                        }
                        return dt;
                    }
                }
            }
            catch { return null; }
        }

        public static DataTable GetAllExpositions()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT ExpositionsID, Title FROM Expositions", conn))
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        if (dt.Columns.Contains("ExpositionsID") && dt.Columns.Contains("Title"))
                        {
                            DataRow row = dt.NewRow();
                            row["ExpositionsID"] = 0;
                            row["Title"] = "-- Все экспозиции --";
                            dt.Rows.InsertAt(row, 0);
                        }
                        return dt;
                    }
                }
            }
            catch { return null; }
        }

        public static string GetUserRole(string login, string password)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"SELECT r.RoleName 
                                     FROM Users u 
                                     JOIN Roles r ON u.RoleID = r.RoleID
                                     WHERE u.Login = @Login AND u.PasswordHash = @Password";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Login", login);
                        cmd.Parameters.AddWithValue("@Password", password);
                        var result = cmd.ExecuteScalar();
                        return result != null ? result.ToString() : null;
                    }
                }
            }
            catch { return null; }
        }
        public static DataTable GetAllRoles()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT RoleID, RoleName FROM Roles", conn))
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        return dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка получения ролей: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
        }
        public static DataRow GetExhibitById(int id)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"SELECT e.ExhibitsID, e.InventoryNumber, e.Title, e.Description, 
                                    e.Material, e.EstimatedValue, e.Condition, e.DateAdded, e.ImageData,
                                    h.Name as HallName, exp.Title as ExpositionTitle,
                                    e.HallsStoragesID, e.ExpositionsID
                            FROM Exhibitss e
                            LEFT JOIN HallsStorages h ON e.HallsStoragesID = h.HallsStoragesID
                            LEFT JOIN Expositions exp ON e.ExpositionsID = exp.ExpositionsID
                            WHERE e.ExhibitsID = @Id";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Id", id);
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            if (dt.Rows.Count > 0)
                                return dt.Rows[0];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка получения экспоната: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return null;
        }

    }
}