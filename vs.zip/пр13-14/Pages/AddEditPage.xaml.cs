﻿using System;
using System.Data;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace пр13_14.Pages
{
    public partial class AddEditPage : Page
    {
        private bool _isEditMode;
        private int _exhibitId;
        private byte[] _currentImageData;
        private bool _isImageChanged = false;

        public AddEditPage(bool isEditMode, DataRow exhibitRow = null)
        {
            InitializeComponent();
            _isEditMode = isEditMode;

            CbHall.ItemsSource = DatabaseHelper.GetAllHalls().DefaultView;
            CbExposition.ItemsSource = DatabaseHelper.GetAllExpositions().DefaultView;

            if (_isEditMode && exhibitRow != null)
            {
                Title = "Редактирование экспоната";
                _exhibitId = Convert.ToInt32(exhibitRow["ExhibitsID"]);

                TxtInventory.Text = exhibitRow["InventoryNumber"].ToString();
                TxtTitle.Text = exhibitRow["Title"].ToString();
                TxtDescription.Text = exhibitRow["Description"] != DBNull.Value ? exhibitRow["Description"].ToString() : "";
                TxtMaterial.Text = exhibitRow["Material"] != DBNull.Value ? exhibitRow["Material"].ToString() : "";

                if (exhibitRow["EstimatedValue"] != DBNull.Value)
                    TxtValue.Text = Convert.ToDecimal(exhibitRow["EstimatedValue"]).ToString();

                string cond = exhibitRow["Condition"] != DBNull.Value ? exhibitRow["Condition"].ToString() : "";
                foreach (ComboBoxItem item in CbCondition.Items)
                {
                    if (item.Content.ToString() == cond) 
                    {
                        CbCondition.Text = cond;
                        break;
                    }
                }
                CbCondition.Text = cond;

                if (exhibitRow["HallsStoragesID"] != DBNull.Value)
                    CbHall.SelectedValue = Convert.ToInt32(exhibitRow["HallsStoragesID"]);

                if (exhibitRow["ExpositionsID"] != DBNull.Value)
                    CbExposition.SelectedValue = Convert.ToInt32(exhibitRow["ExpositionsID"]);

                if (exhibitRow["ImageData"] != DBNull.Value)
                {
                    _currentImageData = (byte[])exhibitRow["ImageData"];
                    LoadImagePreview(_currentImageData);
                }
            }
            else
            {
                Title = "Добавление экспоната";
                CbCondition.SelectedIndex = 1; 
            }
        }

        private void BtnSelectImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Image files (*.jpg, *.jpeg, *.png) | *.jpg; *.jpeg; *.png";
            if (dlg.ShowDialog() == true)
            {
                try
                {
                    _currentImageData = File.ReadAllBytes(dlg.FileName);
                    LoadImagePreview(_currentImageData);
                    _isImageChanged = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка загрузки изображения: " + ex.Message);
                }
            }
        }

        private void LoadImagePreview(byte[] data)
        {
            if (data == null || data.Length == 0)
            {
                ImgPreview.Source = null;
                return;
            }

            BitmapImage bi = new BitmapImage();
            bi.BeginInit();
            bi.CacheOption = BitmapCacheOption.OnLoad;
            bi.StreamSource = new MemoryStream(data);
            bi.EndInit();
            bi.Freeze();
            ImgPreview.Source = bi;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtInventory.Text) || string.IsNullOrWhiteSpace(TxtTitle.Text))
            {
                MessageBox.Show("Заполните обязательные поля (Инв. номер и Название)", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            decimal? value = null;
            if (!string.IsNullOrWhiteSpace(TxtValue.Text))
            {
                if (!decimal.TryParse(TxtValue.Text, out decimal res))
                {
                    MessageBox.Show("Некорректная стоимость", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                value = res;
            }

            int? hallId = CbHall.SelectedValue != null ? Convert.ToInt32(CbHall.SelectedValue) : (int?)null;
            int? expId = CbExposition.SelectedValue != null ? Convert.ToInt32(CbExposition.SelectedValue) : (int?)null;

            bool success;
            if (_isEditMode)
            {
                success = DatabaseHelper.UpdateExhibit(
                    _exhibitId, TxtInventory.Text, TxtTitle.Text, TxtDescription.Text,
                    TxtMaterial.Text, value, CbCondition.Text,
                    hallId, expId, _currentImageData, _isImageChanged);
            }
            else
            {
                success = DatabaseHelper.AddExhibit(
                    TxtInventory.Text, TxtTitle.Text, TxtDescription.Text,
                    TxtMaterial.Text, value, CbCondition.Text,
                    hallId, expId, _currentImageData);
            }

            if (success)
            {
                MessageBox.Show("Сохранено успешно!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                if (Application.Current.MainWindow is MainWindow mw)
                {
                    mw.MainFrame.Navigate(new CatalogPage());
                }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.MainWindow is MainWindow mw)
            {
                mw.MainFrame.GoBack();
            }
        }
    }
}