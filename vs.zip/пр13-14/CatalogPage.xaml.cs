﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace пр13_14.Pages
{
    public partial class CatalogPage : Page
    {
        private string _currentSortField = "DateAdded";
        private bool _isAscending = false;

        public CatalogPage()
        {
            InitializeComponent();

            SetupUIVisibility();

            this.DataContext = this;

            var hallsTable = DatabaseHelper.GetAllHalls();
            var expsTable = DatabaseHelper.GetAllExpositions();

            if (hallsTable != null)
            {
                CbFilterHall.ItemsSource = hallsTable.DefaultView;
                if (CbFilterHall.Items.Count > 0)
                    CbFilterHall.SelectedIndex = 0;
            }

            if (expsTable != null)
            {
                CbFilterExp.ItemsSource = expsTable.DefaultView;
                if (CbFilterExp.Items.Count > 0)
                    CbFilterExp.SelectedIndex = 0;
            }

            LoadData();

            if (CbSort.Items.Count > 0)
                CbSort.SelectedIndex = 0;
        }

        public string UserRole => UserSession.Role;

        private void SetupUIVisibility()
        {
            if (UserSession.IsAdmin)
            {
                BtnAdminPanel.Visibility = Visibility.Visible;
            }
            else
            {
                BtnAdminPanel.Visibility = Visibility.Collapsed;
            }

            if (!UserSession.IsManager)
            {
                BtnAdd.Visibility = Visibility.Collapsed;
            }
        }

        private void LoadData()
        {
            int? hallId = null;
            if (CbFilterHall.SelectedValue != null && CbFilterHall.SelectedValue is DataRowView hallRow)
            {
                hallId = Convert.ToInt32(hallRow["HallsStoragesID"]);
                if (hallId == 0) hallId = null;
            }

            int? expId = null;
            if (CbFilterExp.SelectedValue != null && CbFilterExp.SelectedValue is DataRowView expRow)
            {
                expId = Convert.ToInt32(expRow["ExpositionsID"]);
                if (expId == 0) expId = null;
            }

            string search = TxtSearch?.Text ?? "";

            var dataTable = DatabaseHelper.SearchExhibits(search, hallId, expId, _currentSortField, _isAscending);

            if (dataTable != null)
            {
                var exhibits = new List<ExhibitCardItem>();
                foreach (DataRow row in dataTable.Rows)
                {
                    exhibits.Add(RowToExhibitCard(row));
                }
                lvExhibits.ItemsSource = exhibits;
            }
        }

        private ExhibitCardItem RowToExhibitCard(DataRow row)
        {
            BitmapImage imageSource = null;
            bool hasImage = false;

            if (row["ImageData"] != DBNull.Value)
            {
                byte[] imageData = (byte[])row["ImageData"];
                if (imageData != null && imageData.Length > 0)
                {
                    imageSource = new BitmapImage();
                    imageSource.BeginInit();
                    imageSource.CacheOption = BitmapCacheOption.OnLoad;
                    imageSource.StreamSource = new MemoryStream(imageData);
                    imageSource.EndInit();
                    imageSource.Freeze();
                    hasImage = true;
                }
            }

            return new ExhibitCardItem
            {
                Id = Convert.ToInt32(row["ExhibitsID"]),
                Title = row["Title"].ToString(),
                Description = row["Description"] != DBNull.Value ? row["Description"].ToString() : "Нет описания",
                Condition = row["Condition"] != DBNull.Value ? row["Condition"].ToString() : "Неизвестно",
                HallName = row["HallName"] != DBNull.Value ? row["HallName"].ToString() : "Не размещен",
                ExpositionTitle = row["ExpositionTitle"] != DBNull.Value ? row["ExpositionTitle"].ToString() : "",
                InventoryNumber = row["InventoryNumber"].ToString(),
                EstimatedValue = row["EstimatedValue"] != DBNull.Value ? Convert.ToDecimal(row["EstimatedValue"]) : 0,
                ImageSource = imageSource,
                HasImage = hasImage
            };
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadData();
        }

        private void Filter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadData();
        }

        private void Sort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CbSort.SelectedItem is ComboBoxItem item)
            {
                _currentSortField = item.Tag?.ToString() ?? "DateAdded";
                LoadData();
            }
        }

        private void BtnSortDir_Click(object sender, RoutedEventArgs e)
        {
            _isAscending = !_isAscending;
            BtnSortDir.Content = _isAscending ? "⬆" : "⬇";
            LoadData();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.MainWindow is MainWindow mw)
            {
                mw.MainFrame.Navigate(new AddEditPage(false));
            }
        }

        private void BtnAdminPanel_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.MainWindow is MainWindow mw)
            {
                mw.MainFrame.Navigate(new AdminPanelPage());
            }
        }

        private void Card_Click(object sender, MouseButtonEventArgs e)
        {
            if (e.OriginalSource is Button) return;

            if (sender is Border border && border.DataContext is ExhibitCardItem card)
            {
                if (Application.Current.MainWindow is MainWindow mw)
                {
                    if (UserSession.IsManager)
                    {
                        DataRow row = DatabaseHelper.GetExhibitById(card.Id);
                        if (row != null)
                        {
                            mw.MainFrame.Navigate(new AddEditPage(true, row));
                        }
                    }
                    else
                    {
                        MessageBox.Show("У вас нет прав на редактирование", "Доступ запрещен",
                            MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (!UserSession.IsManager)
            {
                MessageBox.Show("У вас нет прав на удаление записей", "Доступ запрещен",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (sender is Button btn && btn.Tag is int id)
            {
                var result = MessageBox.Show("Вы уверены, что хотите удалить этот экспонат?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    if (DatabaseHelper.DeleteExhibit(id))
                    {
                        MessageBox.Show("Удалено успешно", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadData();
                    }
                }
            }
        }

        // 🔥 ДОБАВИТЬ метод выхода
        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы уверены, что хотите выйти?", "Выход",
                MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                UserSession.Clear();
                if (Application.Current.MainWindow is MainWindow mw)
                {
                    mw.MainFrame.Navigate(new LoginPage());
                }
            }
        }
    }

    public class ExhibitCardItem
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Condition { get; set; }
        public string HallName { get; set; }
        public string ExpositionTitle { get; set; }
        public string InventoryNumber { get; set; }
        public decimal EstimatedValue { get; set; }
        public BitmapImage ImageSource { get; set; }
        public bool HasImage { get; set; }

        public string ConditionColor
        {
            get
            {
                string cond = Condition?.ToLower() ?? "";
                if (cond.Contains("отличное")) return "#FF00C853";
                if (cond.Contains("хорошее")) return "#FF00BCD4";
                if (cond.Contains("удовлетворительное")) return "#FFFFC107";
                if (cond.Contains("плохое")) return "#FFFF5252";
                return "#FF90A4AE";
            }
        }

        public string ConditionIcon
        {
            get
            {
                string cond = Condition?.ToLower() ?? "";
                if (cond.Contains("отличное")) return "✓";
                if (cond.Contains("хорошее")) return "✓";
                if (cond.Contains("удовлетворительное")) return "!";
                if (cond.Contains("плохое")) return "✕";
                return "?";
            }
        }
    }
}